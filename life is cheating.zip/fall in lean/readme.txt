in order to run download python at https://www.python.org/downloads/release/python-3110/

then right click on the webhook.py then and press "open with" and choose python 3.11 and it'll open the cmd prompt and enter your custom webhook message.

credits to sapphire.mas for making this.