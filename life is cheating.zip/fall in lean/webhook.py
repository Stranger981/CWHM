import requests

def send_webhook_message(webhook_url, message, username="ConsoleBot", avatar_url=None):
    data = {
        "content": message,
        "username": username,
        "avatar_url": avatar_url
    }
    
    result = requests.post(webhook_url, json=data)
    
    try:
        result.raise_for_status()
    except requests.exceptions.HTTPError as err:
        print(f"Error: {err}")
    else:
        print(f"Message sent successfully, code {result.status_code}.")

def main():
    webhook_url = "your webhook"
    username = "custom name :3"  
    
    
    avatar_url = ""  # put in image url nga
    
    print("Enter message n press enter to send. Type 'exit' to quit.")
    
    while True:
        message = input("> ")
        
        if message.lower() == "exit":
            print("Exiting...")
            break
        
        send_webhook_message(webhook_url, message, username, avatar_url)

if __name__ == "__main__":
    main()
